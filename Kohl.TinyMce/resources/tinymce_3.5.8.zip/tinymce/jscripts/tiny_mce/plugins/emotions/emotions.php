<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>{#emotions_dlg.title}</title>
	<script type="text/javascript" src="../../tiny_mce_popup.js"></script>
	<script type="text/javascript" src="js/emotions.js"></script>
</head>
<body style="display: none">
	<div align="center">
		<div class="title">{#emotions_dlg.title}:<br /><br /></div>
    <?php
    for ($i = 1; $i < 79; $i++) {
      print "<a href=\"javascript:EmotionsDialog.insert('". $i .".gif','emotions_dlg.". $i ."');\"><img src='images/". $i .".gif' width='18' height='18' border='0' alt='{#emotions_dlg.". $i ."}' title='{#emotions_dlg.". $i ."}' /></a>";
    }
    ?>
	</div>
</body>
</html>
